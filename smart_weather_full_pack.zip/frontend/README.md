Use your UI repo. Copy .env.local to UI root. Optionally run ..\scripts\fix_frontend_imports.ps1 from UI folder, then npm install & npm run dev.
